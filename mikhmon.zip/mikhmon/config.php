<?php
//senver config
$iphost="111.111.111.111"; //ip mikrotik
$sshport="2219"; //port ssh mikrotik, disarankan untuk mengganti port default mikrotik
$userhost="admin"; //user mikrotik
$passwdhost="password"; //password mikrotik

// User Profile
// User Profile Lists 1
$vname1="3 Jam"; //nama voucher
$uactive1="3h"; //masa aktif
$profile1="Voucher3h"; //user profile voucher
$price1="Rp 1.000"; //harga voucher
// User Profile Lists 2
$vname2="1 Hari"; //nama voucher
$uactive2="1d"; //masa aktif
$profile2="Voucher1d"; //user profile voucher
$price2="Rp 3.000"; //harga voucher
// User Profile Lists 3
$vname3="2 Hari"; //nama voucher
$uactive3="2d"; //masa aktif
$profile3="Voucher2d"; //user profile voucher
$price3="Rp 5.000"; //harga voucher
// User Profile Lists 4
$vname4="7 Hari"; //nama voucher
$uactive4="7d"; //masa aktif
$profile4="Voucher1w"; //user profile voucher
$price4="Rp 15.000"; //harga voucher

// Internet Speed Upload/Download
$speed1="512k/680k";
$speed2="512k/720k";
$speed3="512k/1M";
$speed4="512k/2M";
$speed5="1M/1M";
$speed6="1M/2M";

// header voucher
$headerv="Kemangi 41";
// note voucher
$notev="Login dan Logout buka http://k41.net"
?>
